function saveTask(){
    console.log("Saving...");
    //get values
    const title = $("#inputTitle").val();
    const description = $("#inputDescription").val();
    const startDate = $("#inputStartDate").val();
    const status = $("#inputStatus").val();
    const color = $("#inputColor").val();
    const budget = $("#inputBudget").val();
    console.log(title,description,startDate,budget,status,color)
    
    //build the object
let x = new Task(title,description,startDate,status,color,budget)
console.log(x)

    //save to the server

    //display the task

}


function init(){
    console.log("this is a task manager");
    //load data


    //hook events
    $("#btnSave").click(saveTask);
    //document.getElementByID("btnSave")

}

window.onload = init;