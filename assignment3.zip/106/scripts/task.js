class Task{
    constructor(title,desc,startDate,status,color,budget)
    {
        this.title = title;
        this.description = desc;
        this.startDate = startDate;
        this.status = status;
        this.color = color;
        this.budget = budget;
        
    }
}